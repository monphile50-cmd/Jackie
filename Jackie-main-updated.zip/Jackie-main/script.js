const startButton = document.getElementById("startButton");
const continueButton = document.getElementById("continueButton");

const welcomeScreen = document.getElementById("welcomeScreen");
const messageScreen = document.getElementById("messageScreen");
const feelingsScreen = document.getElementById("feelingsScreen");

const yesButton = document.getElementById("yesButton");
const timeButton = document.getElementById("timeButton");
const noButton = document.getElementById("noButton");
const sendMessageButton = document.getElementById("sendMessageButton");
const messageInput = document.getElementById("messageInput");
const feelingsInput = document.getElementById("feelingsInput");

async function saveResponse(page, response) {
    try {
        const result = await fetch("/api/responses", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ page, response })
        });
        if (!result.ok) throw new Error("Could not save response");
        return true;
    } catch (error) {
        console.error(error);
        alert("I couldn't save your response. Please make sure the app is connected to the server and try again.");
        return false;
    }
}

startButton.addEventListener("click", function () {
    welcomeScreen.classList.add("hidden");
    messageScreen.classList.remove("hidden");
});

continueButton.addEventListener("click", async function () {
    const message = messageInput.value.trim();
    if (message) {
        const saved = await saveResponse("message-page", message);
        if (!saved) return;
    }
    messageScreen.classList.add("hidden");
    feelingsScreen.classList.remove("hidden");
});

async function showResponse(message) {
    const saved = await saveResponse("feelings-page", message);
    if (!saved) return;
    feelingsScreen.innerHTML = `
        <h1>Thank You, Jackie ❤️</h1>
        <p>${message}</p>
        <p>Whatever your answer, I appreciate your honesty.</p>
    `;
}

yesButton.addEventListener("click", function () {
    showResponse("I'd like that ❤️");
});

timeButton.addEventListener("click", function () {
    showResponse("I'd like some time to think.");
});

noButton.addEventListener("click", function () {
    showResponse("I don't feel the same way.");
});

sendMessageButton.addEventListener("click", async function () {
    const message = feelingsInput.value.trim();
    if (!message) {
        alert("Please write a message first.");
        feelingsInput.focus();
        return;
    }
    const saved = await saveResponse("feelings-page-custom", message);
    if (saved) {
        feelingsScreen.innerHTML = `
            <h1>Thank You, Jackie ❤️</h1>
            <p>Your message has been received.</p>
            <p>I appreciate you sharing how you feel.</p>
        `;
    }
});
