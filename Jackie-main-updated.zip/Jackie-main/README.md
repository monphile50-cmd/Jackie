# Jackie

A small interactive message website with a local SQLite database for storing responses from the final two pages.

## Run locally

```bash
python3 server.py
```

Then open `http://localhost:3000`.

Responses are stored in `responses.db`. To view them, open `http://localhost:3000/api/responses`.
